import datetime
import time
from typing import List
import requests
import pytz
import eospy.cleos
import eospy.keys
from colorama import Fore, Back, Style, init
from account import Account
import json
import traceback

init(autoreset=True)

accounts = [Account('digitall1111',
                    ['5JfmsEGhX2ARHnW5bKYFfBYs1icrB6cg4d2tenZKmzNYtcmifaR', '5JkV8oNmoKxZd4QjNq7qix27i3yvTxu3ges2UHraM9WCu55sxk2'],
                    ['EOS7KEZb7fRYRWMSmpkpqsUkgBCmXCPwrBxHmXaFuW15jPQSAYG91', 'EOS6NVvEL5cRKUDiDWSVZrhXAQNxRduEVvq3x5BSjUwnqnf6ttt5E'])]


ce = eospy.cleos.Cleos(url='https://wax.cryptolions.io')

def log_add(text, color):
    print(f'{datetime.datetime.utcnow()}: {color}{text}')

def check_max_claims(item, max_claims):
    if len(item['day_claims_at']) < max_claims:
        return True
    else:
        first_time = datetime.datetime.utcfromtimestamp(int(item['day_claims_at'][0]))
        if datetime.datetime.utcnow() > first_time + datetime.timedelta(days=1):
            return True
        else:
            return False

def parse_assets(account_name):
    response = requests.get('https://wax.api.atomicassets.io/atomicassets/v1/assets?'
                            'page=1&limit=1000&template_blacklist=260676&'
                            f'collection_name=farmersworld&owner={account_name}')
    js = json.loads(response.text)
    return js['data']

def find_asset_id(account, template_id):
    assets = parse_assets(account.account_name)
    asset = [i for i in assets if int(i['template']['template_id']) == template_id]
    if len(asset) < 1:
        log_add(f"Couldn't find asset with template id = {template_id}", Fore.RED)
        return None
    asset_id = asset[0]['asset_id']
    return asset_id

def check_items_list(items : List[str]):
    breeding_items = [i for i in items if i['type'] == 'breedings']
    for breeding_item in breeding_items:
        cow_items = [i for i in items if i['type'] == 'animals' and i['asset_id'] == breeding_item['bearer_id']]
        if len(cow_items) > 0:
            items.remove(cow_items[0])
        cow_items = [i for i in items if i['type'] == 'animals' and i['asset_id'] == breeding_item['partner_id']]
        if len(cow_items) > 0:
            items.remove(cow_items[0])

def build_transaction(account, contract, action_name, data):
    payload = {
        "account": contract,
        "name": action_name,
        "authorization": [{
            "actor": account,
            "permission": "active",
        }],
    }

    data = ce.abi_json_to_bin(payload['account'], payload['name'], data)
    # Inserting payload binary form as "data" field in original payload
    payload['data'] = data['binargs']
    # final transaction formed
    trx = {"actions": [payload]}
    trx['expiration'] = str(
        (datetime.datetime.utcnow() + datetime.timedelta(seconds=60)).replace(tzinfo=pytz.UTC))

    return trx

def push_transaction(trx, key):
    try:
        resp = ce.push_transaction(trx, key, broadcast=True)
    except:
        log_add('Push transaction failed', Fore.RED)
        return False

    if resp['processed']['receipt']['status'] == 'executed':
        return True
    else:
        return False

def parse_configs():
    configs = []

    result = ce.get_table(code='farmersworld', index_position=1, key_type='', limit=100,
                          lower_bound=None, scope='farmersworld', table='toolconfs',
                          upper_bound=None)
    configs.extend(result['rows'])

    result = ce.get_table(code='farmersworld', index_position=1, key_type='', limit=100,
                          lower_bound=None, scope='farmersworld', table='anmconf',
                          upper_bound=None)
    configs.extend(result['rows'])

    result = ce.get_table(code='farmersworld', index_position=1, key_type='', limit=100,
                          lower_bound=None, scope='farmersworld', table='cropconf',
                          upper_bound=None)
    configs.extend(result['rows'])

    result = ce.get_table(code='farmersworld', index_position=1, key_type='', limit=100,
                          lower_bound=None, scope='farmersworld', table='breedconf',
                          upper_bound=None)
    configs.extend(result['rows'])

    return configs

def find_config(template_id):
    configs = parse_configs()
    config = [c for c in configs if c['template_id'] == template_id]
    if len(config) > 0:
        return config[0]
    else:
        return None

def parse_account_info(account_name):
    result = ce.get_table(code='farmersworld', index_position=1, key_type='i64', limit=100,
                          lower_bound=account_name, scope='farmersworld', table='accounts',
                          upper_bound=account_name)
    return result['rows'][0]

def check_gold_balance(account_name, need_gold):
    account_info = parse_account_info(account_name)
    if float(account_info['balances'][1].split()[0]) >= need_gold:
        return True
    else:
        return False

def check_food_balance(account_name, need_food):
    account_info = parse_account_info(account_name)
    if float(account_info['balances'][2].split()[0]) >= need_food:
        return True
    else:
        return False

def check_energy(account_name, need_energy):
    account_info = parse_account_info(account_name)
    if account_info['energy'] >= need_energy:
        return True
    else:
        return False

def recover(account, energy_recovered):
    if not check_food_balance(account.account_name, energy_recovered/5):
        log_add(f'NOT ENOUGH {Fore.LIGHTRED_EX}FOOD', Fore.RED)
        return

    data = {'owner':account.account_name, 'energy_recovered':energy_recovered}
    trx = build_transaction(account.account_name, 'farmersworld', 'recover', data)

    if push_transaction(trx, account.key):
        log_add(f'Recovering for {energy_recovered} has been done successfully', Fore.GREEN)
    else:
        log_add(f'Recovering for {energy_recovered} failed', Fore.RED)

def claim(account, asset_id):
    data = {'owner': account.account_name, 'asset_id': asset_id}
    trx = build_transaction(account.account_name, 'farmersworld', 'claim', data)

    if push_transaction(trx, account.key):
        log_add(f'Claiming for {asset_id} has been done successfully', Fore.GREEN)
    else:
        log_add(f'Claiming for {asset_id} failed', Fore.RED)

def crop_claim(account, crop_id):
    data = {'owner': account.account_name, 'crop_id': crop_id}
    trx = build_transaction(account.account_name, 'farmersworld', 'cropclaim', data)

    if push_transaction(trx, account.key):
        log_add(f'Claiming for crop {crop_id} has been done successfully', Fore.GREEN)
    else:
        log_add(f'Claiming for crop {crop_id} failed', Fore.RED)

def feed(account, to, consumable_asset_ids, cow_asset_id):
    memo = f'feed_animal:{cow_asset_id}'
    data = {'from': account.account_name, 'to': to, 'asset_ids': consumable_asset_ids, 'memo': memo}
    trx = build_transaction(account.account_name, 'atomicassets', 'transfer', data)

    if push_transaction(trx, account.key):
        log_add(f'Feeding has been done successfully', Fore.GREEN)
    else:
        log_add(f'Feeding failed', Fore.RED)

def breed(account, to, consumable_asset_ids, cow_asset_ids):
    memo = f'breed_animal:{cow_asset_ids}'
    data = {'from': account.account_name, 'to': to, 'asset_ids': consumable_asset_ids, 'memo': memo}
    trx = build_transaction(account.account_name, 'atomicassets', 'transfer', data)

    if push_transaction(trx, account.key):
        log_add(f'Breeding has been done successfully', Fore.GREEN)
    else:
        log_add(f'Breeding failed', Fore.RED)

def repair(account, asset_id, full_durability):
    if not check_gold_balance(account.account_name, full_durability/5):
        log_add(f'NOT ENOUGH {Fore.YELLOW}GOLD', Fore.RED)
        return

    data = {'asset_owner':account.account_name, 'asset_id':asset_id}
    trx = build_transaction(account.account_name, 'farmersworld', 'repair', data)

    if push_transaction(trx, account.key):
        log_add(f'Repairing for {asset_id} has been done successfully', Fore.GREEN)
    else:
        log_add(f'Repairing for {asset_id} failed', Fore.RED)

def parse_items(account):
    account.items = []

    for table in account.tables:
        result = ce.get_table(code='farmersworld', index_position=table[1], key_type='i64', limit=100,
                              lower_bound=account.account_name, scope='farmersworld', table=table[0],
                              upper_bound=account.account_name)
        for row in result['rows']:
            row['type'] = table[0]

        account.items.extend(result['rows'])

    check_items_list(account.items)

def check_items(account):
    is_changed = False

    for item in account.items:
        config = find_config(item['template_id'])
        if config is None:
            log_add("Couldn't find config", Fore.RED)
            return

        if item['type'] == 'tools':
            estimated_time = datetime.datetime.utcfromtimestamp(int(item['next_availability']))
            if datetime.datetime.utcnow() >= estimated_time:
                is_changed = True

                if item['current_durability'] < config['durability_consumed']:
                    repair(account, item['asset_id'], item['durability'])
                if not check_energy(account.account_name, config['energy_consumed']):
                    recover(account, 500)
                    # 500 - MAX ENERGY, DON'T UPDATE ONLINE

                claim(account, item['asset_id'])
        elif item['type'] == 'crops':
            estimated_time = datetime.datetime.utcfromtimestamp(int(item['next_availability']))
            if datetime.datetime.utcnow() >= estimated_time:
                is_changed = True

                if not check_energy(account.account_name, config['energy_consumed']):
                    recover(account, 500)
                    # 500 - MAX ENERGY, DON'T UPDATE ONLINE

                crop_claim(account, item['asset_id'])
        elif item['type'] == 'animals':
            estimated_time = datetime.datetime.utcfromtimestamp(int(item['next_availability']))
            if datetime.datetime.utcnow() >= estimated_time:
                if check_max_claims(item, config['daily_claim_limit']):
                    is_changed = True
                    consumable_asset_id = find_asset_id(account, config['consumed_card'])
                    if consumable_asset_id is not None:
                        feed(account, 'farmersworld', [consumable_asset_id], item['asset_id'])
        elif item['type'] == 'breedings':
            estimated_time = datetime.datetime.utcfromtimestamp(int(item['next_availability']))
            if datetime.datetime.utcnow() >= estimated_time:
                if check_max_claims(item, config['daily_claim_limit']):
                    is_changed = True
                    consumable_asset_id = find_asset_id(account, config['consumed_card'])
                    if consumable_asset_id is not None:
                        breed(account, 'farmersworld', [consumable_asset_id], f'{item["bearer_id"]},{item["partner_id"]}')

    if is_changed:
        time.sleep(15)
        parse_items(account)


for account in accounts:
    account.key = eospy.keys.EOSKey(account.private_keys[1])
    parse_items(account)

while True:
    for account in accounts:
        try:
            check_items(account)
        except:
            log_add(f'HANDLED ERROR: {traceback.format_exc()}', Fore.RED)
        time.sleep(10)


#TODO change 'type' in 'items' to smth else